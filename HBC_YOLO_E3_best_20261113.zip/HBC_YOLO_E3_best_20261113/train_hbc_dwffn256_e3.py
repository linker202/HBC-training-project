"""Train the original HBC-YOLO model on the rice detection dataset."""

import argparse
import sys
import warnings
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT / "ultralytics"))

import ultralytics.nn.tasks as tasks  # noqa: E402
from ultralytics.nn.modules.bottleneck import BottleneckViT  # noqa: E402
from ultralytics import YOLO  # noqa: E402

# Make the legacy HBC module visible to parse_model even when an older
# tasks.py is present on the cloud machine.
tasks.BottleneckViT = BottleneckViT


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data",
        default=None,
        help="Dataset YAML. Defaults to the original rice dataset YAML.",
    )
    parser.add_argument(
        "--model",
        default=None,
        help="Model YAML. Defaults to the original HBC YAML.",
    )
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--name", default="hbc_dwffn256_e3_seed0")
    parser.add_argument("--device", default="0")
    parser.add_argument("--batch", type=int, default=8)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=300)
    return parser.parse_args()


def main():
    args = parse_args()
    warnings.filterwarnings("ignore")

    model_yaml = (
        Path(args.model).expanduser().resolve()
        if args.model
        else PROJECT_ROOT
        / "ultralytics"
        / "ultralytics"
        / "cfg"
        / "models"
        / "11"
        / "yolo11-VIT-SEAM.yaml"
    )
    data_yaml = (
        Path(args.data).expanduser().resolve()
        if args.data
        else PROJECT_ROOT
        / "datasets"
        / "ricedetect_new"
        / "ricedetect_new"
        / "data.yaml"
    )

    model = YOLO(str(model_yaml))
    model.info()
    model.train(
        data=str(data_yaml),
        cache=False,
        imgsz=896,
        epochs=args.epochs,
        lr0=0.005,
        box=9.0,
        single_cls=False,
        batch=args.batch,
        workers=args.workers,
        device=args.device,
        optimizer="SGD",
        amp=True,
        pretrained=False,
        project=str(PROJECT_ROOT / "train" / "compare"),
        name=args.name,
        patience=300,
        seed=args.seed,
        deterministic=True,
        mosaic=1.0,
        close_mosaic=0,
        mixup=0.0,
        hsv_h=0.015,
        hsv_s=0.7,
        hsv_v=0.4,
        degrees=2.0,
        translate=0.05,
        scale=0.3,
        flipud=0.0,
        fliplr=0.5,
        save=True,
        save_period=50,
    )


if __name__ == "__main__":
    main()
