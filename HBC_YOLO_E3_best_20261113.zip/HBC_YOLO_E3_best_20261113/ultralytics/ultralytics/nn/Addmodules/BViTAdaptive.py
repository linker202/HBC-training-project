import math

import torch
import torch.nn as nn


__all__ = ["AdaptiveBottleneckViT"]


class DropPath(nn.Module):
    def __init__(self, drop_prob=0.0):
        super().__init__()
        self.drop_prob = float(drop_prob)

    def forward(self, x):
        if self.drop_prob == 0.0 or not self.training:
            return x
        keep_prob = 1.0 - self.drop_prob
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        mask = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
        return x * mask.floor() / keep_prob


class AdaptiveMHSA(nn.Module):
    """MHSA with a learnable temperature for each attention head."""

    def __init__(self, dim, num_heads=4, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        if dim % num_heads != 0:
            raise ValueError(f"dim={dim} must be divisible by num_heads={num_heads}")

        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.base_scale = self.head_dim ** -0.5
        self.logit_scale = nn.Parameter(torch.zeros(num_heads, 1, 1))
        self.qkv = nn.Linear(dim, dim * 3, bias=True)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        b, n, c = x.shape
        qkv = self.qkv(x).reshape(b, n, 3, self.num_heads, self.head_dim)
        q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)

        scale = self.base_scale * self.logit_scale.clamp(-2.0, 2.0).exp()
        attn = (q @ k.transpose(-2, -1)) * scale.unsqueeze(0)
        attn = self.attn_drop(attn.softmax(dim=-1))
        x = (attn @ v).transpose(1, 2).reshape(b, n, c)
        return self.proj_drop(self.proj(x))


class LocalMixFFN(nn.Module):
    """FFN with depthwise spatial mixing for dense prediction."""

    def __init__(self, dim, mlp_ratio=2.0, drop=0.0):
        super().__init__()
        hidden_dim = int(dim * mlp_ratio)
        self.fc1 = nn.Linear(dim, hidden_dim)
        self.dwconv = nn.Conv2d(
            hidden_dim, hidden_dim, kernel_size=3, stride=1, padding=1,
            groups=hidden_dim, bias=True
        )
        self.act = nn.GELU()
        self.drop1 = nn.Dropout(drop)
        self.fc2 = nn.Linear(hidden_dim, dim)
        self.drop2 = nn.Dropout(drop)

    def forward(self, x, height, width):
        b, _, _ = x.shape
        x = self.fc1(x)
        x_map = x.transpose(1, 2).reshape(b, -1, height, width)
        x = x + self.dwconv(x_map).flatten(2).transpose(1, 2)
        x = self.drop1(self.act(x))
        return self.drop2(self.fc2(x))


class AdaptiveViTBlock(nn.Module):
    def __init__(self, dim, num_heads=4, mlp_ratio=2.0, drop_path=0.0):
        super().__init__()
        # Conditional positional encoding preserves the input resolution.
        self.pos_embed = nn.Conv2d(
            dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=True
        )
        self.norm1 = nn.LayerNorm(dim)
        self.attn = AdaptiveMHSA(dim, num_heads=num_heads)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = LocalMixFFN(dim, mlp_ratio=mlp_ratio)
        self.drop_path = DropPath(drop_path)

        # LayerScale lets the model learn how much global/local context to use.
        self.gamma_attn = nn.Parameter(torch.full((dim,), 1e-3))
        self.gamma_ffn = nn.Parameter(torch.full((dim,), 1e-3))

    def forward(self, x):
        b, c, h, w = x.shape
        x = x + self.pos_embed(x)
        seq = x.flatten(2).transpose(1, 2)
        seq = seq + self.drop_path(self.gamma_attn * self.attn(self.norm1(seq)))
        seq = seq + self.drop_path(self.gamma_ffn * self.ffn(self.norm2(seq), h, w))
        return seq.transpose(1, 2).reshape(b, c, h, w)


class AdaptiveBottleneckViT(nn.Module):
    """Shape-compatible replacement for BottleneckViT used at P5/32."""

    def __init__(
        self,
        c,
        c_mid=None,
        num_heads=4,
        mlp_ratio=2.0,
        drop_path=0.0,
    ):
        super().__init__()
        c_mid = c_mid if c_mid is not None else max(64, c // 2)
        if c_mid % num_heads != 0:
            raise ValueError(f"c_mid={c_mid} must be divisible by num_heads={num_heads}")

        self.reduce = nn.Sequential(
            nn.Conv2d(c, c_mid, kernel_size=1, bias=False),
            nn.BatchNorm2d(c_mid),
            nn.SiLU(inplace=True),
        )
        self.vit = AdaptiveViTBlock(
            c_mid,
            num_heads=num_heads,
            mlp_ratio=mlp_ratio,
            drop_path=drop_path,
        )
        self.expand = nn.Sequential(
            nn.Conv2d(c_mid, c, kernel_size=1, bias=False),
            nn.BatchNorm2d(c),
        )

        # Start with a conservative 10% branch contribution and learn it.
        self.branch_logit = nn.Parameter(torch.full((1, c, 1, 1), math.log(0.1 / 0.9)))

    def forward(self, x):
        residual = self.expand(self.vit(self.reduce(x)))
        return x + self.branch_logit.sigmoid() * residual
