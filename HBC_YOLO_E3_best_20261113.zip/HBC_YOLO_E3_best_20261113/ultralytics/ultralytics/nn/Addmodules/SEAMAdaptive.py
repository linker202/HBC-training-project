import math

import torch
import torch.nn as nn


__all__ = ["AdaptiveSEAM"]


class ResidualDepthwiseBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.depthwise = nn.Sequential(
            nn.Conv2d(
                channels, channels, kernel_size=3, stride=1, padding=1,
                groups=channels, bias=False
            ),
            nn.BatchNorm2d(channels),
            nn.GELU(),
        )
        self.pointwise = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.GELU(),
        )

    def forward(self, x):
        return self.pointwise(x + self.depthwise(x))


class AdaptiveSEAM(nn.Module):
    """SEAM with adaptive pooling and bounded bidirectional channel gating."""

    def __init__(self, c1, n=1, reduction=16, gate_limit=0.5):
        super().__init__()
        if n < 1:
            raise ValueError("n must be at least 1")
        if reduction < 1:
            raise ValueError("reduction must be at least 1")
        if not 0.0 < gate_limit < 1.0:
            raise ValueError("gate_limit must be in (0, 1)")

        hidden = max(c1 // reduction, 8)
        self.context = nn.Sequential(*(ResidualDepthwiseBlock(c1) for _ in range(n)))
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.channel_mlp = nn.Sequential(
            nn.Conv2d(c1, hidden, kernel_size=1, bias=False),
            nn.GELU(),
            nn.Conv2d(hidden, c1, kernel_size=1, bias=True),
        )

        # Learn the descriptor mixture and gate amplitude per channel.
        self.pool_logit = nn.Parameter(torch.tensor(0.0))
        amplitude_init = 0.5
        self.amplitude_logit = nn.Parameter(
            torch.full((1, c1, 1, 1), math.log(amplitude_init / (1.0 - amplitude_init)))
        )
        self.gate_limit = float(gate_limit)

        # Identity initialization avoids disturbing the pretrained feature scale.
        nn.init.zeros_(self.channel_mlp[-1].weight)
        nn.init.zeros_(self.channel_mlp[-1].bias)

    def forward(self, x):
        context = self.context(x)
        pool_mix = self.pool_logit.sigmoid()
        descriptor = pool_mix * self.avg_pool(context)
        descriptor = descriptor + (1.0 - pool_mix) * self.max_pool(context)

        logits = self.channel_mlp(descriptor)
        amplitude = self.gate_limit * self.amplitude_logit.sigmoid()
        gate = 1.0 + amplitude * torch.tanh(logits)
        return x * gate
