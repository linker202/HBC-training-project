# ultralytics/nn/modules/vitblock.py
import math
import torch
import torch.nn as nn


class DropPath(nn.Module):
    """Stochastic Depth (DropPath). Default off if drop_prob=0."""
    def __init__(self, drop_prob: float = 0.0):
        super().__init__()
        self.drop_prob = float(drop_prob)

    def forward(self, x):
        if self.drop_prob == 0.0 or not self.training:
            return x
        keep_prob = 1.0 - self.drop_prob
        # Work with tensors of shape (B, ...), broadcast across non-batch dims
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
        random_tensor = torch.floor(random_tensor)
        return x.div(keep_prob) * random_tensor


class MLP(nn.Module):
    """Transformer FFN/MLP."""
    def __init__(self, dim: int, mlp_ratio: float = 4.0, dropout: float = 0.0):
        super().__init__()
        hidden = int(dim * mlp_ratio)
        self.fc1 = nn.Linear(dim, hidden)
        self.act = nn.GELU()
        self.drop1 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(hidden, dim)
        self.drop2 = nn.Dropout(dropout)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop1(x)
        x = self.fc2(x)
        x = self.drop2(x)
        return x


class MHSA(nn.Module):
    """Multi-Head Self-Attention for sequences (B, N, C)."""
    def __init__(self, dim: int, num_heads: int = 8, attn_dropout: float = 0.0, proj_dropout: float = 0.0):
        super().__init__()
        assert dim % num_heads == 0, f"dim {dim} must be divisible by num_heads {num_heads}"
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=True)
        self.attn_drop = nn.Dropout(attn_dropout)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_dropout)

    def forward(self, x):
        # x: (B, N, C)
        B, N, C = x.shape
        qkv = self.qkv(x)  # (B, N, 3C)
        qkv = qkv.reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # each: (B, heads, N, head_dim)

        attn = (q @ k.transpose(-2, -1)) * self.scale  # (B, heads, N, N)
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        out = attn @ v  # (B, heads, N, head_dim)
        out = out.transpose(1, 2).reshape(B, N, C)  # (B, N, C)
        out = self.proj(out)
        out = self.proj_drop(out)
        return out


class ViTBlock(nn.Module):
    """
    Minimal Vision Transformer block for feature maps.
    Input:  (B, C, H, W)
    Output: (B, C, H, W)
    """
    def __init__(
        self,
        c: int,
        num_heads: int = 8,
        mlp_ratio: float = 4.0,
        attn_dropout: float = 0.0,
        proj_dropout: float = 0.0,
        drop_path: float = 0.0,
        norm_layer=nn.LayerNorm,
    ):
        super().__init__() 
        self.c = c
        self.norm1 = norm_layer(c)
        self.attn = MHSA(c, num_heads=num_heads, attn_dropout=attn_dropout, proj_dropout=proj_dropout)
        self.drop_path1 = DropPath(drop_path)

        self.norm2 = norm_layer(c)
        self.mlp = MLP(c, mlp_ratio=mlp_ratio, dropout=proj_dropout)
        self.drop_path2 = DropPath(drop_path)

    def forward(self, x):
        # x: (B, C, H, W) -> (B, N, C)
        B, C, H, W = x.shape
        assert C == self.c, f"Expected channels {self.c}, got {C}"
        n = H * W
        x_seq = x.flatten(2).transpose(1, 2)  # (B, N, C)

        # Pre-LN + MHSA + residual
        x_seq = x_seq + self.drop_path1(self.attn(self.norm1(x_seq)))
        # Pre-LN + MLP + residual
        x_seq = x_seq + self.drop_path2(self.mlp(self.norm2(x_seq)))

        # Back to feature map
        x_out = x_seq.transpose(1, 2).reshape(B, C, H, W)
        return x_out

class BottleneckViT(nn.Module):
    """
    Bottleneck ViT for feature maps: reduce -> ViTBlock -> expand + residual.
    Input/Output: (B, C, H, W)
    Args in YAML: [c, c_mid, num_heads]
    """
    def __init__(self, c: int, c_mid: int = None, num_heads: int = 4):
        super().__init__()
        self.c = c
        self.c_mid = c_mid if c_mid is not None else max(64, c // 2)

        self.reduce = nn.Sequential(
            nn.Conv2d(c, c, 3, padding=1, groups=c),
            nn.BatchNorm2d(c),
            nn.SiLU(),
            nn.Conv2d(c, self.c_mid, 1),
            nn.BatchNorm2d(self.c_mid),
        )
        self.vit = ViTBlock(c=self.c_mid, num_heads=num_heads, mlp_ratio=2.0)

        self.expand = nn.Conv2d(self.c_mid, c, kernel_size=1, stride=1, padding=0, bias=False)
        self.bn2 = nn.BatchNorm2d(c)

    def forward(self, x):
        # Older full-module checkpoints retain the original reduce/bn1/act.
        if hasattr(self, "bn1"):
            y = self.act(self.bn1(self.reduce(x)))
        else:
            y = self.reduce(x)
        y = self.vit(y)
        y = self.bn2(self.expand(y))
        return x + y
