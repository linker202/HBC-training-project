"""Validate the archived best checkpoint on the original validation split."""
import argparse
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "ultralytics"))
from ultralytics import YOLO
if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", required=True)
    p.add_argument("--device", default="0")
    args = p.parse_args()
    model = YOLO(str(ROOT / "best_run/weights/best.pt"))
    model.val(data=args.data, split="val", imgsz=896, batch=8,
              device=args.device, iou=0.7, max_det=300,
              project=str(ROOT / "validation"), name="e3_best")
