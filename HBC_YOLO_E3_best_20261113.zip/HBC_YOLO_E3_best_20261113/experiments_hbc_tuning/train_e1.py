from bootstrap import launch

if __name__ == '__main__':
    launch('e1')
