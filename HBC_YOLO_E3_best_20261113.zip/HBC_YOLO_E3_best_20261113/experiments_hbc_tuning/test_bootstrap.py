"""Offline bootstrap control-flow tests; no package download, GPU, or real venv creation."""
import importlib.util
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch, MagicMock

spec = importlib.util.spec_from_file_location('boot', Path(__file__).with_name('bootstrap.py'))
boot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(boot)


class BootstrapTests(unittest.TestCase):
    def test_clean_environment(self):
        with patch.dict(boot.os.environ, {'PYTHONPATH': 'bad', 'PYTHONHOME': 'bad',
                                         'PIP_TARGET': 'bad', 'CUDA_VISIBLE_DEVICES': '0'}):
            e = boot.clean_env()
        self.assertNotIn('PYTHONPATH', e)
        self.assertNotIn('PIP_TARGET', e)
        self.assertEqual(e['CUDA_VISIBLE_DEVICES'], '0')
        self.assertEqual(e['OMP_NUM_THREADS'], '1')

    def test_install_reuse_and_failure(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            req = root / 'requirements.txt'
            req.write_text('numpy==1.26.4\n')
            fcntl = types.SimpleNamespace(LOCK_EX=1, flock=lambda *a: None)
            builder = MagicMock()
            with patch.object(boot, 'ROOT', root), patch.object(boot, 'REQ', req), \
                 patch.object(boot.sys, 'platform', 'linux'), patch.object(boot.sys, 'version_info', (3, 12, 3)), \
                 patch.object(boot.sys, 'argv', ['train_e1.py']), \
                 patch.dict(sys.modules, {'fcntl': fcntl}), \
                 patch.object(boot.venv, 'EnvBuilder', return_value=builder) as factory, \
                 patch.object(boot.shutil, 'disk_usage', return_value=types.SimpleNamespace(free=20*1024**3)), \
                 patch.object(boot, 'run') as run, \
                 patch.object(boot.subprocess, 'check_output', return_value='numpy==1.26.4\n'), \
                 patch.object(boot.os, 'execve') as execute:
                builder.create.side_effect = lambda p: p.mkdir(parents=True, exist_ok=True)
                boot.launch('e1')
                self.assertFalse(factory.call_args.kwargs['system_site_packages'])
                self.assertEqual(run.call_count, 5)  # 3 installs + pip check + probe
                self.assertEqual(execute.call_count, 1)
                self.assertEqual(len(list(root.rglob('hbc_environment.json'))), 1)
                run.reset_mock()
                boot.launch('e2')
                self.assertEqual(run.call_count, 2)  # validate only, no reinstall
                self.assertEqual(factory.call_count, 1)
                execute.reset_mock()
                run.side_effect = RuntimeError('probe failure')
                with self.assertRaises(RuntimeError):
                    boot.launch('e3')
                execute.assert_not_called()


if __name__ == '__main__':
    unittest.main()
