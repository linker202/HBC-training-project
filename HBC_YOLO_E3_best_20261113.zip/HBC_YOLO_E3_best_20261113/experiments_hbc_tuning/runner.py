"""Fail-closed HBC experiments. Run one of train_e1/e2/e3.py, not this file."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
from datetime import datetime

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
VARIANTS = {'e1': {'close_mosaic': 0}, 'e2': {'box': 9.0},
            'e3': {'close_mosaic': 0, 'box': 9.0}}


def require(ok, message):
    if not ok:
        raise RuntimeError('CHECK FAILED: ' + message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True).encode()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str), encoding='utf-8')


def sources():
    pins = json.loads((HERE / 'source_lock.json').read_text())
    for rel, expected in pins.items():
        require((ROOT / rel).is_file(), 'missing source ' + rel)
        require(sha(ROOT / rel) == expected, 'source differs from frozen project: ' + rel)
    # Include added source files as well as pinned ones in cross-server comparison.
    actual = {p.relative_to(ROOT).as_posix(): sha(p)
              for p in sorted((ROOT / 'ultralytics/ultralytics').rglob('*.py'))}
    actual.update({p.name: sha(p) for p in sorted(HERE.iterdir())
                   if p.suffix in {'.py', '.yaml'} or p.name in {'source_lock.json', 'environment_requirements.txt'}})
    return digest(actual)


def data_check(data_path):
    import yaml
    import numpy as np
    from ultralytics.data.utils import check_det_dataset, IMG_FORMATS, img2label_paths
    raw = yaml.safe_load(data_path.read_text(encoding='utf-8'))
    require(not raw.get('download'), 'automatic data downloads are prohibited')
    d = check_det_dataset(str(data_path), autodownload=False)
    require(d['names'] == {0: 'rice', 1: 'piaoyang'} and d['nc'] == 2, 'dataset classes')
    result, file_lists, split_stems = {}, {}, []
    for split in ('train', 'val', 'test'):
        require(isinstance(d.get(split), str), split + ' must be one images directory, not a manifest/list')
        folder = Path(d[split]).resolve()
        require(folder.is_dir() and folder.name == 'images', split + ' images folder missing')
        files = sorted(p for p in folder.rglob('*') if p.is_file() and p.suffix[1:].lower() in IMG_FORMATS)
        require(bool(files), split + ' has no images')
        stems = {p.stem for p in files}
        require(len(stems) == len(files), split + ' contains duplicate image stems')
        split_stems.append(stems)
        items, counts, missing, empty = [], [0, 0], 0, 0
        label_fingerprints = {}
        for i, p in enumerate(files):
            canonical_labels = []
            label = Path(img2label_paths([str(p)])[0])
            if label.is_file():
                lines = [x.split() for x in label.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
                require(all(len(x) == 5 for x in lines), 'not detection labels: ' + str(label))
                if lines:
                    a = np.asarray(lines, dtype=float)
                    require(np.isfinite(a).all(), 'nonfinite labels: ' + str(label))
                    require(np.isin(a[:, 0], [0, 1]).all(), 'invalid class: ' + str(label))
                    require(((a[:, 1:] >= 0) & (a[:, 1:] <= 1)).all()
                            and (a[:, 3:] > 0).all(), 'invalid normalized boxes: ' + str(label))
                    require(len(np.unique(a, axis=0)) == len(a), 'duplicate annotation rows: ' + str(label))
                    for c in (0, 1):
                        counts[c] += int((a[:, 0] == c).sum())
                    canonical_labels = a.astype(np.float32).tolist()
                else:
                    empty += 1
                label_hash = sha(label)
            else:
                missing += 1  # Missing labels are retained as backgrounds, not silently discarded.
                label_hash = 'MISSING_BACKGROUND_LABEL'
            items.append([p.relative_to(folder).as_posix(), sha(p), label_hash])
            label_fingerprints[str(p)] = digest(canonical_labels)
            if i % 1000 == 0:
                print('[DATA]', split, i, '/', len(files), flush=True)
        result[split] = {'images': len(files), 'instances': counts, 'missing_labels': missing,
                         'empty_labels': empty, 'content_sha256': digest(items)}
        file_lists[split] = [str(p) for p in files]
        file_lists[split + '_labels'] = label_fingerprints
    for i in range(3):
        for j in range(i):
            require(not split_stems[i].intersection(split_stems[j]), 'image stems overlap between splits')
    require(result['train']['images'] == 12745 and result['val']['images'] == 1577,
            'expected original train=12745, val=1577; do not use oversampling or a different split')
    require(result['train']['instances'] == [250840, 17114], 'original training label counts differ')
    return result, file_lists


def model_check(net):
    import torch
    from ultralytics.nn.modules.bottleneck import BottleneckViT
    from ultralytics.nn.Addmodules.SEAM import SEAM
    from ultralytics.nn.modules import Detect
    layers = net.model
    blocks = [m for m in net.modules() if isinstance(m, BottleneckViT)]
    require(len(blocks) == 1 and isinstance(layers[11], BottleneckViT), 'BViT position/count')
    b = blocks[0]
    require((b.c, b.c_mid, b.vit.attn.num_heads) == (256, 128, 4), 'BViT dimensions')
    require(isinstance(b.reduce, torch.nn.Sequential) and len(b.reduce) == 5, 'DWConv reduction')
    require(b.reduce[0].groups == 256 and b.reduce[0].kernel_size == (3, 3), 'DWConv kernel/groups')
    require(b.reduce[3].in_channels == 256 and b.reduce[3].out_channels == 128, 'pointwise dimensions')
    require((b.vit.mlp.fc1.in_features, b.vit.mlp.fc1.out_features,
             b.vit.mlp.fc2.in_features, b.vit.mlp.fc2.out_features) == (128, 256, 256, 128), 'FFN')
    require(sum(isinstance(m, SEAM) for m in net.modules()) == 1 and isinstance(layers[18], SEAM), 'SEAM')
    require(type(layers[-1]) is Detect and layers[-1].nc == 2
            and list(layers[-1].f) == [18, 21, 24], 'Detect connections/classes')
    return {'parameters': sum(p.numel() for p in net.parameters()),
            'stride': net.stride.tolist(), 'c_mid': 128, 'heads': 4, 'ffn': 256}


def state_digest(net):
    h = hashlib.sha256()
    for key, value in net.state_dict().items():
        h.update(key.encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def main(variant):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=ROOT / 'datasets/ricedetect_new/ricedetect_new/data.yaml')
    parser.add_argument('--reference', type=Path, help='optional cross-server fingerprint comparison; not required')
    parser.add_argument('--check-only', action='store_true', help='preflight only; no training')
    args = parser.parse_args()
    require(int(os.environ.get('WORLD_SIZE', '1')) == 1, 'no distributed launch')
    require(os.environ.get('RANK', '-1') == '-1', 'unset RANK; use plain python, not torchrun')
    os.environ['OMP_NUM_THREADS'] = '1'
    os.environ['MKL_NUM_THREADS'] = '1'
    source_hash = sources()
    sys.path.insert(0, str(ROOT / 'ultralytics'))
    import yaml
    import numpy as np
    import cv2
    import torch
    import ultralytics
    import ultralytics.nn.tasks as tasks
    from ultralytics.nn.modules.bottleneck import BottleneckViT
    from ultralytics import YOLO
    from ultralytics.utils.torch_utils import init_seeds
    require(Path(ultralytics.__file__).resolve().is_relative_to(ROOT / 'ultralytics'), 'wrong Ultralytics import')
    require(torch.cuda.is_available() and torch.cuda.device_count() == 1, 'exactly one visible CUDA GPU required')
    require(cv2.resize(np.zeros((32, 32, 3), np.uint8), (16, 16)).shape == (16, 16, 3), 'OpenCV bridge')
    require(isinstance(cv2.UMat(8, 8, cv2.CV_8UC3).get(), np.ndarray), 'OpenCV NumPy type mismatch')
    env = {'python': platform.python_version(), 'torch': str(torch.__version__),
           'numpy': np.__version__, 'opencv': cv2.__version__, 'ultralytics': ultralytics.__version__,
           'cuda': torch.version.cuda, 'cudnn': torch.backends.cudnn.version(),
           'gpu': torch.cuda.get_device_name(0)}
    data, files = data_check(args.data.resolve())
    tasks.BottleneckViT = BottleneckViT
    # Trainer seed is args.seed + 1 + RANK; plain single-process RANK=-1 gives seed=0.
    init_seeds(0, deterministic=True)
    model = YOLO(str(HERE / 'model.yaml'))
    structure = model_check(model.model)
    initial_hash = state_digest(model.model)
    net = model.model.to('cuda').eval()
    with torch.no_grad():
        out = net(torch.zeros(1, 3, 896, 896, device='cuda'))
        require(torch.isfinite(out[0]).all().item(), 'nonfinite full-resolution forward output')
    model.model.cpu()
    torch.cuda.empty_cache()
    reference = {'schema': 1, 'source_sha256': source_hash, 'data': data,
                 'environment': env, 'model': structure, 'initial_state_sha256': initial_hash}
    if args.reference:
        expected = json.loads(args.reference.read_text(encoding='utf-8'))
        require(reference == expected, 'cross-server reference mismatch; compare reference.json fields. Do not bypass.')
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    run_name = 'hbc_dwffn256_' + variant + '_seed0_' + stamp
    audit_dir = ROOT / 'train/hbc_tuning_audits' / run_name
    audit_dir.mkdir(parents=True, exist_ok=False)
    write_json(audit_dir / 'reference.json', reference)
    base = yaml.safe_load((HERE / 'baseline_args.yaml').read_text(encoding='utf-8'))
    settings = dict(base)
    settings.pop('save_dir', None)
    settings.update(VARIANTS[variant])
    settings.update(model=str(HERE / 'model.yaml'), data=str(args.data.resolve()),
                    project=str(ROOT / 'train/compare'), name=run_name, device='0')
    changes = {k: {'old': base[k], 'new': v} for k, v in settings.items()
               if base.get(k) != v and k not in {'model', 'data', 'project', 'name', 'device'}}
    require(set(changes) == set(VARIANTS[variant]), 'unintended training parameter differences')
    report = {'status': 'preflight_passed', 'variant': variant, 'changes': changes,
              'requested': settings, 'reference': reference, 'executable': sys.executable,
              'cross_server_verified': bool(args.reference),
              'interpretation': 'E3 vs original changes TWO factors; E3 vs E1 or E2 changes ONE.'}
    write_json(audit_dir / 'audit.json', report)
    print('CHECKS PASSED. Local fingerprint saved:', audit_dir / 'reference.json', flush=True)
    print('Intended changes:', changes, flush=True)
    if args.check_only:
        return

    def pretrain(trainer):
        effective = vars(trainer.args)
        for k, v in settings.items():
            require(effective.get(k) == v, 'effective setting changed: ' + k)
        require(type(trainer.optimizer) is torch.optim.SGD, 'optimizer is not SGD')
        require(bool(trainer.amp) and trainer.accumulate == 8, 'AMP or gradient accumulation changed')
        require(trainer.start_epoch == 0, 'resume/pretrained training is prohibited')
        require(model_check(trainer.model) == structure, 'trainer rebuilt a different model')
        require(state_digest(trainer.model) == initial_hash, 'training initialization differs from reference')
        for split, loader in [('train', trainer.train_loader), ('val', trainer.test_loader)]:
            actual = [str(Path(p).resolve()) for p in loader.dataset.im_files]
            require(sorted(actual) == sorted(files[split]), 'loader filtered/changed ' + split + ' images')
            require(len(loader.dataset.labels) == len(files[split]), 'loader label count changed')
            for label in loader.dataset.labels:
                key = str(Path(label['im_file']).resolve())
                require(label['normalized'] and label['bbox_format'] == 'xywh', 'loader box format')
                array = np.concatenate((label['cls'], label['bboxes']), axis=1).astype(np.float32)
                require(digest(array.tolist()) == files[split + '_labels'][key],
                        'stale/changed label cache: ' + key + '; inspect the cache before retrying')
        groups = []
        for group in trainer.optimizer.param_groups:
            require(math.isclose(group['lr'], .005) and math.isclose(group['momentum'], .937), 'SGD lr/momentum')
            require(any(math.isclose(group['weight_decay'], x) for x in (0, .0005)), 'SGD decay')
            groups.append({k: v for k, v in group.items() if k != 'params'})
        report.update(status='training', effective=effective, optimizer_groups=groups)
        write_json(audit_dir / 'audit.json', report)
        write_json(Path(trainer.save_dir) / 'experiment_audit.json', report)

    model.add_callback('on_pretrain_routine_end', pretrain)
    try:
        model.train(**settings)
        report.update(status='completed', save_dir=str(model.trainer.save_dir),
                      last_epoch=int(model.trainer.epoch) + 1)
        require(report['last_epoch'] == 300, 'training returned before epoch 300')
    except BaseException as exc:
        report.update(status='failed_or_interrupted', error=repr(exc))
        raise
    finally:
        write_json(audit_dir / 'audit.json', report)
        if getattr(model, 'trainer', None) and Path(model.trainer.save_dir).is_dir():
            write_json(Path(model.trainer.save_dir) / 'experiment_audit.json', report)
