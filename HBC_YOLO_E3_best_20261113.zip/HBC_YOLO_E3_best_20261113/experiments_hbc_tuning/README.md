# HBC DWConv + FFN256 三台服务器实验

三个入口共享 runner.py、冻结的 baseline_args.yaml/model.yaml 和 source_lock.json。
必须上传整个 experiments_hbc_tuning 文件夹到项目根目录，不能只传三个入口。
不覆盖历史训练脚本、模型源码、数据、权重或结果。

## 实验定义

| 入口 | close_mosaic | box | 单变量参照 |
|---|---:|---:|---|
| 已有 DWConv+FFN256 | 30 | 7.5 | 历史对照 |
| train_e1.py | 0 | 7.5 | 相对历史只改 close_mosaic |
| train_e2.py | 30 | 9.0 | 相对历史只改 box |
| train_e3.py | 0 | 9.0 | 相对 E1 只改 box；相对 E2 只改 close_mosaic |

E3 相对历史同时改两项，不能称为单变量。三组使用相同随机种子和随机初始化，不加载已有权重。
300 epochs、896、batch=8、workers=8、seed=0、SGD、lr0=.005、lrf=.01、momentum=.937、
weight_decay=.0005、warmup=3、cls=.5、dfl=1.5 等来自已归档的 DWConv+FFN256 args.yaml。
不提供临时调 batch、epochs、seed 的命令行选项，避免三个实例配置悄悄分叉。

## 校验范围与限制

- 检查本地 Ultralytics 全部已锁定 Python 源码和 default.yaml 的 SHA256，检查本地导入路径。
  若提示源码不一致，请同步本地项目对应源码到三台服务器；不要删除/改写锁文件绕过校验。
- 校验 BViT 位置、256→128、DWConv3×3、4 heads、FFN256、SEAM 和 Detect 连接。
- GPU 上执行 896×896 前向；检查 NumPy/OpenCV 双向数组桥，避免此前克隆环境问题。
- 校验原始 train=12745、val=1577、train instances=[250840,17114]、两类名称、标签格式、范围、
  重复标注行和跨划分重名。缺失标签作为背景记录，不擅自创建或修改标签。
- 对 train/val/test 的全部图像与标签逐文件哈希，分别保存审计指纹，不要求第一台参考文件。
  这里只读取 test 文件以核对划分，没有在 test 上预测或调参。完整扫描需要几分钟，不能跳过。
- 记录 Python、PyTorch、NumPy、OpenCV、Ultralytics、CUDA、cuDNN、GPU 型号。
  默认不进行跨服务器匹配，也不因服务器 GPU 型号不同拒绝启动；建议尽量保持环境一致。
- 真正训练前再次核对全部有效参数、实际 SGD/AMP/梯度累积、随机初始化权重和加载器图像清单。
  发现训练器过滤损坏图像会终止，不在不同数据子集上继续训练。
- 每台的 reference.json 只是本机审计指纹；默认未验证三台数据内容和环境完全一致。
  也不能追溯证明历史实验数据/环境一致，或保证 GPU 运算逐位确定。
  数据应在训练期间保持只读；图像近重复和标注语义错误不在本校验的自动识别范围。
- 三个实验使用相同代码包版本。可选 --reference 用于额外的跨服务器严格比较，不是启动条件。

## 第一步：上传与自动环境

将本地 experiments_hbc_tuning 放到三台服务器的 /root/autodl-tmp/yolo11_new 下。
同步项目 ultralytics/ultralytics 中与 source_lock.json 对应的源码。
现在直接用服务器 Python 3.12 启动，入口自动建立干净的虚拟环境，不依赖 cv2_probe_env。
首次执行会在项目 `.hbc_envs/py312_cu128_指纹/` 中创建环境，不继承系统 site-packages，
不向 base/conda 安装任何包。三台独立创建，无需互传参考文件。同一台上的三个入口复用同一环境。
锁定 PyTorch 2.8.0+cu128、torchvision 0.23.0+cu128、NumPy 1.26.4、OpenCV 4.11.0.86，
其他直接依赖列在 environment_requirements.txt；不安装其他 OpenCV 变体，也不安装 pip 版 Ultralytics。
PyTorch 从官方 CUDA wheel 源安装，其余包从 PyPI 安装。传递依赖由 pip 解析，未声称全部锁定；
实际解析版本保存到虚拟环境 requirements-resolved.txt，复验时应一并保存比较。
安装需要访问互联网、至少 12 GiB 空闲磁盘和支持 CUDA 12.8 的宿主 NVIDIA 驱动。
虚拟环境不能自动安装 Python 3.12、修复驱动或分配 GPU；这些条件不满足会明确停止。
初次下载可能较慢且耗费数 GB 流量。安装失败保留目录，下次启动重试；不删除旧环境。
已安装环境每次由外部 Python 启动时重新执行 pip check、依赖版本检查、OpenCV 桥测试、
CUDA 矩阵乘法/NMS 和本地模型包导入测试，成功后才进入训练检查。
依赖清单或 bootstrap.py 改动会使用新指纹目录，不覆盖旧环境。
不要直接调用自动环境内的 Python；按下面的普通 python 命令启动，让每次启动都经过环境复核。
自动安装不解决源码指纹不一致：若仍报 metrics.py 不匹配，需单独核对源码差异，不能绕过。

## 第二步：可选的本机预检

```bash
cd /root/autodl-tmp/yolo11_new
python experiments_hbc_tuning/train_e1.py --check-only
```

不需要在服务器之间复制参考文件。三台可以直接独立启动；正式启动也会执行预检。
另外两台可把入口换为 train_e2.py、train_e3.py，使用 --check-only 只做本机预检。
check-only 不执行训练器构建和反向传播，
有效优化器、AMP、加载器核对在正式训练开始前的回调执行。

## 第三步：分别启动

第一台：
```bash
cd /root/autodl-tmp/yolo11_new
nohup python -u experiments_hbc_tuning/train_e1.py > hbc_e1.log 2>&1 &
```

第二台：
```bash
cd /root/autodl-tmp/yolo11_new
nohup python -u experiments_hbc_tuning/train_e2.py > hbc_e2.log 2>&1 &
```

第三台：
```bash
cd /root/autodl-tmp/yolo11_new
nohup python -u experiments_hbc_tuning/train_e3.py > hbc_e3.log 2>&1 &
```

这些日志名固定；不要重复执行覆盖日志或重复启动同一实验。
训练结果使用微秒时间戳新目录：train/compare/hbc_dwffn256_eN_seed0_时间戳。
审计记录：train/hbc_tuning_audits/同名目录/audit.json。
训练目录同时保存 experiment_audit.json。只有实际训练到 300 轮且返回成功才标记 completed。
启动失败时先看 CHECK FAILED 原因；不要降低分辨率、batch 或禁用 AMP 来绕过，否则不再是该对照。
三份脚本无自动断点续训；中断时保留日志/权重，单独核对后再制定续训方案。

## 收集结果

每组收集完整结果目录（args.yaml、results.csv、曲线、best.pt、experiment_audit.json），
对应 hbc_eN.log，以及各自审计目录中的 reference.json。比较验证集而不是 test；box 权重变化后的
加权 box loss 数值不能直接与旧组比较，主要看 mAP50-95、分类别 AP 和后期平均表现。

本地交付进行了语法和不依赖 GPU 的逻辑检查。此电脑缺少训练用 PyTorch 环境，
没有声称完成 GPU 前向、训练器回调或真实训练验证；云端预检是正式运行必需步骤。
