"""Linux-only isolated environment bootstrap; never installs into base/conda."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import venv

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
REQ = HERE / 'environment_requirements.txt'
TORCH = ['torch==2.8.0+cu128', 'torchvision==0.23.0+cu128']


def clean_env():
    env = dict(os.environ)
    # Ignore inherited Python/pip package injection and conda pip configuration.
    for key in list(env):
        if key.startswith('PIP_') or key in {'PYTHONPATH', 'PYTHONHOME', 'PYTHONUSERBASE', 'VIRTUAL_ENV'}:
            env.pop(key, None)
    env.update(PYTHONNOUSERSITE='1', PIP_CONFIG_FILE=os.devnull,
               OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', MPLBACKEND='Agg',
               YOLO_AUTOINSTALL='false', PYTHONUNBUFFERED='1')
    return env


def run(argv, env):
    print('[ENV]', ' '.join(map(str, argv)), flush=True)
    subprocess.run(list(map(str, argv)), env=env, check=True, cwd=ROOT)


def launch(variant):
    if '--help' in sys.argv or '-h' in sys.argv:
        from runner import main
        main(variant)
        return
    if sys.platform != 'linux' or sys.version_info[:2] != (3, 12):
        raise RuntimeError('Use Linux Python 3.12 to launch. venv does not install a new Python interpreter.')
    spec = hashlib.sha256(REQ.read_bytes() + Path(__file__).read_bytes()
                          + repr(TORCH).encode()).hexdigest()[:12]
    folder = ROOT / '.hbc_envs' / ('py312_cu128_' + spec)
    python = folder / 'bin/python'
    ready = folder / 'hbc_environment.json'
    if Path(sys.prefix).resolve() == folder.resolve():
        if not ready.is_file():
            raise RuntimeError('Incomplete environment; relaunch using the system Python 3.12.')
        from runner import main
        main(variant)
        return
    env = clean_env()
    folder.parent.mkdir(exist_ok=True)
    import fcntl
    # Shared on one machine: concurrent launches cannot install into the same venv.
    with (folder.parent / (spec + '.lock')).open('a') as lock:
        print('[ENV] Waiting for environment setup lock:', folder, flush=True)
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        if not ready.exists():
            if shutil.disk_usage(folder.parent).free < 12 * 1024**3:
                raise RuntimeError('At least 12 GiB free space is required for a fresh CUDA environment.')
            print('[ENV] Creating isolated venv; no system-site-packages:', folder, flush=True)
            venv.EnvBuilder(with_pip=True, system_site_packages=False).create(folder)
            pip = [python, '-I', '-m', 'pip']
            run(pip + ['install', '--no-cache-dir', '--index-url', 'https://pypi.org/simple',
                       'pip==24.3.1'], env)
            run(pip + ['install', '--no-cache-dir', '--index-url', 'https://download.pytorch.org/whl/cu128',
                       '-c', REQ] + TORCH, env)
            run(pip + ['install', '--no-cache-dir', '--index-url', 'https://pypi.org/simple',
                       '-r', REQ] + TORCH, env)
        # Revalidate on every launch, including a venv copied by AutoDL cloning.
        run([python, '-I', '-m', 'pip', 'check'], env)
        run([python, '-I', HERE / 'probe_environment.py', ROOT, folder, REQ], env)
        freeze = subprocess.check_output([str(python), '-I', '-m', 'pip', 'freeze'], env=env, text=True)
        (folder / 'requirements-resolved.txt').write_text(freeze, encoding='utf-8')
        ready.write_text(json.dumps({'spec': spec, 'python': str(python),
                                    'requirements': REQ.read_text(), 'torch': TORCH}, indent=2), encoding='utf-8')
    env['VIRTUAL_ENV'] = str(folder)
    env['PATH'] = str(folder / 'bin') + os.pathsep + env.get('PATH', '')
    print('[ENV] Verified. Starting', variant, 'with', python, flush=True)
    os.execve(str(python), [str(python), '-s', str(HERE / ('train_' + variant + '.py')),
                           *sys.argv[1:]], env)
