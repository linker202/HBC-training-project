"""Executed in an isolated subprocess, before training or declaring a venv ready."""
import importlib.metadata as md
import json
from pathlib import Path
import sys


def main():
    root, folder, req = map(Path, sys.argv[1:])
    assert Path(sys.prefix).resolve() == folder.resolve(), 'wrong Python prefix'
    assert 'include-system-site-packages = false' in (folder / 'pyvenv.cfg').read_text().lower()
    for line in req.read_text().splitlines():
        if line.strip() and not line.startswith('#'):
            name, version = line.strip().split('==')
            assert md.version(name) == version, 'dependency version mismatch: ' + name
    opencv = [d.metadata['Name'] for d in md.distributions()
              if d.metadata.get('Name', '').lower().startswith('opencv-')]
    assert opencv == ['opencv-python'], 'multiple OpenCV distributions: ' + repr(opencv)
    import numpy as np
    import cv2
    def check_cv(stage):
        assert Path(np.__file__).resolve().is_relative_to(folder.resolve())
        assert Path(cv2.__file__).resolve().is_relative_to(folder.resolve())
        a = np.zeros((64, 64, 3), dtype=np.uint8)
        assert cv2.resize(a, (32, 32)).shape == (32, 32, 3)
        b = cv2.UMat(8, 8, cv2.CV_8UC3).get()
        assert isinstance(b, np.ndarray)
        assert cv2.resize(b, (4, 4)).shape == (4, 4, 3)
        print('[ENV] OpenCV bridge OK:', stage, flush=True)
    check_cv('before torch')
    import torch
    import torchvision
    assert torch.__version__ == '2.8.0+cu128'
    assert torchvision.__version__ == '0.23.0+cu128'
    assert torch.cuda.is_available(), 'CUDA unavailable; check instance GPU and host NVIDIA driver'
    a = torch.ones((8, 8), device='cuda')
    assert (a @ a).sum().item() == 512
    from torchvision.ops import nms
    assert len(nms(torch.tensor([[0., 0., 1., 1.]], device='cuda'),
                   torch.ones(1, device='cuda'), .5)) == 1
    check_cv('after torch')
    sys.path.insert(0, str(root / 'ultralytics'))
    import ultralytics
    from ultralytics.nn.modules.bottleneck import BottleneckViT
    assert Path(ultralytics.__file__).resolve().is_relative_to(root / 'ultralytics')
    check_cv('after local ultralytics import')
    print('[ENV] Versions:', json.dumps({'numpy': np.__version__, 'opencv': cv2.__version__,
          'torch': torch.__version__, 'torchvision': torchvision.__version__,
          'gpu': torch.cuda.get_device_name(0)}), flush=True)


if __name__ == '__main__':
    main()
